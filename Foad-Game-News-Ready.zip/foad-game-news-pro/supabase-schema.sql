-- Run this in Supabase SQL Editor.
create table if not exists public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'GAMING',
  body text not null,
  image_url text,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.news enable row level security;

-- Everyone can read published news.
create policy "Public can read published news"
on public.news for select
using (published = true);

-- Authenticated users cannot write through these policies.
-- The admin policy below restricts writes to the one admin email.
create policy "Admin can insert"
on public.news for insert to authenticated
with check ((auth.jwt()->>'email') = 'YOUR_EMAIL@example.com');

create policy "Admin can update"
on public.news for update to authenticated
using ((auth.jwt()->>'email') = 'YOUR_EMAIL@example.com')
with check ((auth.jwt()->>'email') = 'YOUR_EMAIL@example.com');

create policy "Admin can delete"
on public.news for delete to authenticated
using ((auth.jwt()->>'email') = 'YOUR_EMAIL@example.com');

export const SUPABASE_URL = "https://cuoxbhhhcurflfuzulvz.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_O_s0bMJ0dvZls-XBpJFXfw_hYcvZ0dz";
export const ADMIN_EMAIL = "foadpourabasi@gmail.com";

import {createClient} from "https://esm.sh/@supabase/supabase-js@2";
import {SUPABASE_URL,SUPABASE_ANON_KEY,ADMIN_EMAIL} from "./config.js";
const db=createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
const $=id=>document.getElementById(id);
$("loginBtn").onclick=async()=>{const {error}=await db.auth.signInWithPassword({email:$("email").value,password:$("password").value});$("loginMsg").textContent=error?error.message:"";if(!error)load()};
$("logoutBtn").onclick=()=>db.auth.signOut().then(()=>location.reload());
async function load(){const {data:{user}}=await db.auth.getUser();if(!user)return; if(user.email.toLowerCase()!==ADMIN_EMAIL.toLowerCase()){await db.auth.signOut();$("loginMsg").textContent="This account is not authorized.";return} $("login").hidden=true;$("dashboard").hidden=false;$("who").textContent=user.email;render()}
async function render(){const {data}=await db.from("news").select("*").order("created_at",{ascending:false});$("items").innerHTML=(data||[]).map(n=>`<div class="item"><div><small>${esc(n.category)}</small><br><b>${esc(n.title)}</b></div><button onclick="removeNews('${n.id}')">Delete</button></div>`).join("")||"<p class=muted>No news yet.</p>"}
$("publishBtn").onclick=async()=>{const {data:{user}}=await db.auth.getUser();if(!user||user.email.toLowerCase()!==ADMIN_EMAIL.toLowerCase())return;
const {error}=await db.from("news").insert({title:$("title").value,category:$("category").value||"GAMING",body:$("body").value,image_url:$("image").value||null,published:true});
$("pubMsg").textContent=error?error.message:"Published successfully.";if(!error){$("title").value=$("category").value=$("body").value=$("image").value="";render()}};
window.removeNews=async id=>{await db.from("news").delete().eq("id",id);render()};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
const {data:{session}}=await db.auth.getSession();if(session)load();
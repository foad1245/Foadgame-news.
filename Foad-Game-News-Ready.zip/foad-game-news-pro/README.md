# Foad Game News — Pro

This version uses Supabase Auth + PostgreSQL + Row Level Security.

1. Create a Supabase project.
2. In Authentication, create ONE admin user with your email/password.
3. Replace YOUR_EMAIL@example.com in supabase-schema.sql with that exact email.
4. Run supabase-schema.sql in Supabase SQL Editor.
5. Copy config.example.js to config.js and enter the Supabase Project URL, anon/publishable key and your admin email.
6. Upload all files to GitHub Pages / Netlify / Vercel.

Security:
- Never put the Supabase service_role/secret key in frontend files.
- Only the configured admin email is allowed to write/delete news by database RLS.
- Public visitors can only read published news.

For a custom domain, point DNS to the hosting provider.

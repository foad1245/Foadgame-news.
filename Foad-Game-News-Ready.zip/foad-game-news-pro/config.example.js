// Copy this file to config.js and fill in your Supabase project values.
// NEVER publish service_role keys in this project.
export const SUPABASE_URL = "https://YOUR_PROJECT.supabase.co";
export const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
export const ADMIN_EMAIL = "YOUR_EMAIL@example.com";

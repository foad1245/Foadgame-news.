import {createClient} from "https://esm.sh/@supabase/supabase-js@2";
import {SUPABASE_URL,SUPABASE_ANON_KEY} from "./config.js";
const db=createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
const grid=document.querySelector("#newsGrid");
const {data,error}=await db.from("news").select("*").eq("published",true).order("created_at",{ascending:false});
if(error){grid.innerHTML="<p>Could not load news.</p>";}else if(!data.length){grid.innerHTML="<p>No news published yet.</p>";}else{
grid.innerHTML=data.map(n=>`<article class="card"><div class="thumb">${n.image_url?`<img src="${n.image_url}" style="width:100%;height:100%;object-fit:cover">`:"🎮"}</div><div class="card-body"><small>${esc(n.category)}</small><h3>${esc(n.title)}</h3><p>${esc(n.body)}</p></div></article>`).join("");
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}